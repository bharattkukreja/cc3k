#include "stationary.h"
using namespace std;

Stationary::Stationary() {}

Stationary::~Stationary() {}
