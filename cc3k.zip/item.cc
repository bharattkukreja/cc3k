#include "item.h"
using namespace std;

bool Item::isItem() const { return true; }


Item::Item() {}

Item::~Item() {}
