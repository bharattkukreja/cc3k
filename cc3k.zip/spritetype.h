#ifndef __SPRITETYPE_H__
#define __SPRITETYPE_H__

enum class SpriteType { Human, Elf, Dwarf, Orc, Vampire, Werewolf, Troll, Goblin, Merchant, Phoenix, Dragon, Stairs, Gold, AtkPot, DefPot, HPPot };

#endif


