#ifndef __COMMANDS_H__
#define __COMMANDS_H__

// A list of commands that GameMap uses 
enum class CommandType {no, so, ea, we, ne, nw, se, sw, u, a, h, e, d, o, r, q, y, n, no_value};

#endif
