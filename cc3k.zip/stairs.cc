#include "stairs.h"
#include "spritetype.h"
using namespace std;

Stairs::Stairs() {}

Stairs::~Stairs() {}


SpriteType Stairs::getType() const { return SpriteType::Stairs; }
